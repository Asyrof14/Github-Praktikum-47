import matematika

jari_jari = float(input("Masukkan jari-jari lingkaran: "))
lingkaran = matematika.luas_lingkaran(jari_jari)
print(f"Luas lingkaran dengan jari-jari {jari_jari} adalah: {lingkaran}")

sisi = float(input("Masukkan panjang sisi persegi: "))
persegi = matematika.luas_persegi(sisi)
print(f"Luas persegi dengan sisi {sisi} adalah: {persegi}")

panjang = float(input("Masukkan panjang sisi persegi: "))
lebar = float(input("Masukkan panjang sisi persegi: "))
persegi_panjang = matematika.luas_persegi_panjang(panjang, lebar)
print(f"Luas persegi dengan sisi {panjang, lebar} adalah: {persegi_panjang}")