Phi = 3.14

def luas_lingkaran(jari_jari):
    return Phi * jari_jari * jari_jari

def luas_persegi(sisi):
    return sisi * sisi

def luas_persegi_panjang(panjang, lebar):
    return panjang * lebar